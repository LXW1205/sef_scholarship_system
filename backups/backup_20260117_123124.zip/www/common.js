/**
 * common.js - Shared UI components and logic for ScholarNet
 */

document.addEventListener('DOMContentLoaded', () => {
    // Check Authentication and Role
    if (!checkAuth()) return;

    // Inject Header
    injectHeader();

    // Inject Footer
    injectFooter();

    // Handle Authentication UI
    handleAuthUI();

    // Initialize Password Toggles
    initPasswordToggles();

    // Initialize Lucide Icons
    if (window.lucide) {
        window.lucide.createIcons();
    }
});

/**
 * Initializes peek/visibility toggles for all password fields.
 * Looks for <input type="password"> and adds a toggle button if it's in a .relative container.
 */
function initPasswordToggles() {
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
        const container = input.closest('.relative');
        if (!container) return;

        // Check if toggle already exists
        if (container.querySelector('.password-toggle')) return;

        // Adjust input padding to make room for toggle
        input.classList.add('pr-12');

        const toggleBtn = document.createElement('button');
        toggleBtn.type = 'button';
        toggleBtn.className = 'password-toggle absolute inset-y-0 right-0 pr-3 flex items-center text-muted-foreground hover:text-foreground transition-colors focus:outline-none';
        toggleBtn.innerHTML = '<i data-lucide="eye" class="w-5 h-5"></i>';

        const showPassword = () => {
            input.type = 'text';
            toggleBtn.innerHTML = '<i data-lucide="eye-off" class="w-5 h-5 text-primary"></i>';
            if (window.lucide) window.lucide.createIcons();
        };

        const hidePassword = () => {
            input.type = 'password';
            toggleBtn.innerHTML = '<i data-lucide="eye" class="w-5 h-5"></i>';
            if (window.lucide) window.lucide.createIcons();
        };

        // Mouse events
        toggleBtn.addEventListener('mousedown', showPassword);
        toggleBtn.addEventListener('mouseup', hidePassword);
        toggleBtn.addEventListener('mouseleave', hidePassword);

        // Touch events
        toggleBtn.addEventListener('touchstart', (e) => {
            e.preventDefault(); // Prevent context menu
            showPassword();
        });
        toggleBtn.addEventListener('touchend', hidePassword);
        toggleBtn.addEventListener('touchcancel', hidePassword);

        container.appendChild(toggleBtn);
    });
}

/**
 * Checks if the user is authenticated and has the correct role for the current path.
 * Redirects to login if unauthorized.
 */
function checkAuth() {
    const path = window.location.pathname;

    // Public pages don't need auth checks here (handled by handleAuthUI for UI only)
    if (!path.includes('/admin/') && !path.includes('/student/') &&
        !path.includes('/reviewer/') && !path.includes('/committee/')) {
        return true;
    }

    const token = localStorage.getItem("token") || sessionStorage.getItem("token");
    const user = JSON.parse(localStorage.getItem("user") || sessionStorage.getItem("user") || "{}");

    if (!token || !user.role) {
        window.location.href = "/login.html";
        return false;
    }

    // Role-based path protection
    if (path.includes('/admin/') && user.role !== 'Admin') {
        window.location.href = "/login.html";
        return false;
    }
    if (path.includes('/student/') && user.role !== 'Student') {
        window.location.href = "/login.html";
        return false;
    }
    if (path.includes('/reviewer/') && user.role !== 'Reviewer') {
        window.location.href = "/login.html";
        return false;
    }
    if (path.includes('/committee/') && user.role !== 'Committee') {
        window.location.href = "/login.html";
        return false;
    }

    return true;
}


function injectHeader() {
    const headerContainer = document.getElementById('header-container');
    if (!headerContainer) return;

    const user = JSON.parse(localStorage.getItem("user") || sessionStorage.getItem("user") || "{}");
    const path = window.location.pathname;

    // Determine which header to inject
    if (user.role === 'Admin' && (path.includes('/admin/') || path.includes('profile.html') || path.includes('notifications.html'))) {
        injectAdminHeader(headerContainer);
    } else if (user.role === 'Student' && (path.includes('/student/') || path.includes('profile.html') || path.includes('notifications.html'))) {
        injectStudentHeader(headerContainer);
    } else if (user.role === 'Reviewer' && (path.includes('/reviewer/') || path.includes('profile.html') || path.includes('notifications.html'))) {
        injectReviewerHeader(headerContainer);
    } else if (user.role === 'Committee' && (path.includes('/committee/') || path.includes('profile.html') || path.includes('notifications.html'))) {
        injectCommitteeHeader(headerContainer);
    } else {
        injectPublicHeader(headerContainer);
    }
}

function injectPublicHeader(container) {
    container.innerHTML = `
    <nav class="bg-primary text-primary-foreground border-b border-border">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center gap-2">
                    <i data-lucide="graduation-cap" class="w-6 h-6"></i>
                    <h1 class="text-xl font-bold"><a href="/index.html">ScholarNet</a></h1>
                </div>
                <div class="flex items-center gap-8" id="navLinks">
                    <a href="/index.html" class="hover:text-muted-foreground transition-colors inline-flex items-center gap-2 whitespace-nowrap">
                        <i data-lucide="home" class="w-4 h-4"></i>
                        <span>Home</span>
                    </a>
                    <a href="/scholarships.html" class="hover:text-muted-foreground transition-colors inline-flex items-center gap-2 whitespace-nowrap">
                        <i data-lucide="book-open" class="w-4 h-4"></i>
                        <span>Scholarships</span>
                    </a>
                    <a href="/login.html" id="loginLink" class="hover:text-muted-foreground transition-colors inline-flex items-center gap-2 whitespace-nowrap">
                        <i data-lucide="log-in" class="w-4 h-4"></i>
                        <span>Login</span>
                    </a>
                    <a href="/register.html" id="registerLink" class="hover:text-muted-foreground transition-colors inline-flex items-center gap-2 whitespace-nowrap">
                        <i data-lucide="user-plus" class="w-4 h-4"></i>
                        <span>Register</span>
                    </a>
                    <a href="#" id="dashboardLink" style="display: none;" class="hover:text-muted-foreground transition-colors inline-flex items-center gap-2 whitespace-nowrap">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                        <span>Dashboard</span>
                    </a>
                    <button id="logoutBtn" style="display: none;" class="px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors inline-flex items-center gap-2 whitespace-nowrap">
                        <i data-lucide="log-out" class="w-4 h-4"></i>
                        <span>Logout</span>
                    </button>
                </div>
            </div>
        </div>
    </nav>
    `;
}

function injectAdminHeader(container) {
    const currentPath = window.location.pathname;
    container.innerHTML = `
    <nav class="bg-primary text-primary-foreground border-b border-border">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center gap-2">
                    <i data-lucide="graduation-cap" class="w-6 h-6"></i>
                    <h1 class="text-xl font-bold"><a href="/admin/dashboard-admin.html">ScholarNet Admin</a></h1>
                </div>
                <div class="flex items-center gap-6">
                    <a href="/admin/dashboard-admin.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('dashboard') ? 'font-semibold' : ''}">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i> Dashboard
                    </a>
                    <a href="/admin/users-management.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('users') ? 'font-semibold' : ''}">
                        <i data-lucide="users" class="w-4 h-4"></i> Users
                    </a>
                    <a href="/admin/scholarships-management.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('scholarships') ? 'font-semibold' : ''}">
                        <i data-lucide="award" class="w-4 h-4"></i> Scholarships
                    </a>
                    <a href="/admin/applications-management.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('applications') ? 'font-semibold' : ''}">
                        <i data-lucide="clipboard-check" class="w-4 h-4"></i> Applications
                    </a>
                    <a href="/admin/notifications-admin.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('notifications') ? 'font-semibold' : ''}">
                        <i data-lucide="bell" class="w-4 h-4"></i> Notifications
                    </a>
                    <a href="/admin/profile-admin.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('profile') ? 'font-semibold' : ''}">
                        <i data-lucide="user" class="w-4 h-4"></i> Profile
                    </a>
                    <button id="logoutBtn" class="px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors flex items-center gap-1">
                        <i data-lucide="log-out" class="w-4 h-4"></i> Logout
                    </button>
                </div>
            </div>
        </div>
    </nav>
    `;
}

function injectStudentHeader(container) {
    const currentPath = window.location.pathname;
    container.innerHTML = `
    <nav class="bg-primary text-primary-foreground border-b border-border">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center gap-2">
                    <i data-lucide="graduation-cap" class="w-6 h-6"></i>
                    <h1 class="text-xl font-bold"><a href="/student/dashboard-student.html">Student Portal</a></h1>
                </div>
                <div class="flex items-center gap-6">
                    <a href="/student/dashboard-student.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('dashboard') ? 'font-semibold' : ''}">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i> Dashboard
                    </a>
                    <a href="/student/scholarships-student.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('scholarships') ? 'font-semibold' : ''}">
                        <i data-lucide="award" class="w-4 h-4"></i> Scholarships
                    </a>
                    <a href="/student/applications-student.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('applications') ? 'font-semibold' : ''}">
                        <i data-lucide="file-text" class="w-4 h-4"></i> My Applications
                    </a>
                    <a href="/student/notifications-student.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('notifications') ? 'font-semibold' : ''}">
                        <i data-lucide="bell" class="w-4 h-4"></i> Notifications
                    </a>
                    <a href="/student/profile-student.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('profile') ? 'font-semibold' : ''}">
                        <i data-lucide="user" class="w-4 h-4"></i> Profile
                    </a>
                    <button id="logoutBtn" class="px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors flex items-center gap-1">
                        <i data-lucide="log-out" class="w-4 h-4"></i> Logout
                    </button>
                </div>
            </div>
        </div>
    </nav>
    `;
}

function injectReviewerHeader(container) {
    const currentPath = window.location.pathname;
    container.innerHTML = `
    <nav class="bg-primary text-primary-foreground border-b border-border">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center gap-2">
                    <i data-lucide="graduation-cap" class="w-6 h-6"></i>
                    <h1 class="text-xl font-bold"><a href="/reviewer/dashboard-reviewer.html">Reviewer Dashboard</a></h1>
                </div>
                <div class="flex items-center gap-6">
                    <a href="/reviewer/dashboard-reviewer.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('dashboard') ? 'font-semibold' : ''}">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i> Dashboard
                    </a>
                    <a href="/reviewer/application-assignments.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('assignments') ? 'font-semibold' : ''}">
                        <i data-lucide="clipboard-list" class="w-4 h-4"></i> Assignments
                    </a>
                    <a href="/reviewer/notifications-reviewer.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('notifications') ? 'font-semibold' : ''}">
                        <i data-lucide="bell" class="w-4 h-4"></i> Notifications
                    </a>
                    <a href="/reviewer/profile-reviewer.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('profile') ? 'font-semibold' : ''}">
                        <i data-lucide="user" class="w-4 h-4"></i> Profile
                    </a>
                    <button id="logoutBtn" class="px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors flex items-center gap-1">
                        <i data-lucide="log-out" class="w-4 h-4"></i> Logout
                    </button>
                </div>
            </div>
        </div>
    </nav>
    `;
}

function injectCommitteeHeader(container) {
    const currentPath = window.location.pathname;
    container.innerHTML = `
    <nav class="bg-primary text-primary-foreground border-b border-border">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center gap-2">
                    <i data-lucide="graduation-cap" class="w-6 h-6"></i>
                    <h1 class="text-xl font-bold"><a href="/committee/dashboard-committee.html">Committee Portal</a></h1>
                </div>
                <div class="flex items-center gap-6">
                    <a href="/committee/dashboard-committee.html" class="hover:text-muted-foreground transition-colors flex items-center gap-2 ${currentPath.includes('dashboard') ? 'font-semibold' : ''}">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i> Dashboard
                    </a>
                    <a href="/committee/applications-committee.html" class="hover:text-muted-foreground transition-colors flex items-center gap-2 ${currentPath.includes('applications') ? 'font-semibold' : ''}">
                        <i data-lucide="clipboard-list" class="w-4 h-4"></i> Applications
                    </a>
                    <a href="/committee/application-decisions.html" class="hover:text-muted-foreground transition-colors flex items-center gap-2 ${currentPath.includes('decisions') ? 'font-semibold' : ''}">
                        <i data-lucide="gavel" class="w-4 h-4"></i> Decisions
                    </a>
                    <a href="/committee/schedule-interviews.html" class="hover:text-muted-foreground transition-colors flex items-center gap-2 ${currentPath.includes('interviews') ? 'font-semibold' : ''}">
                        <i data-lucide="calendar" class="w-4 h-4"></i> Interviews
                    </a>
                    <a href="/committee/notifications-committee.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('notifications') ? 'font-semibold' : ''}">
                        <i data-lucide="bell" class="w-4 h-4"></i> Notifications
                    </a>
                    <a href="/committee/profile-committee.html" class="hover:text-muted-foreground transition-colors flex items-center gap-1 ${currentPath.includes('profile') ? 'font-semibold' : ''}">
                        <i data-lucide="user" class="w-4 h-4"></i> Profile
                    </a>
                    <button id="logoutBtn" class="px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors flex items-center gap-2">
                        <i data-lucide="log-out" class="w-4 h-4"></i> Logout
                    </button>
                </div>
            </div>
        </div>
    </nav>
    `;
}

function injectFooter() {
    const footerContainer = document.getElementById('footer-container');
    if (!footerContainer) return;

    footerContainer.innerHTML = `
    <footer class="bg-muted/50 border-t border-border py-8 mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                <div class="flex items-center gap-2">
                    <i data-lucide="graduation-cap" class="w-5 h-5 text-primary"></i>
                    <span class="font-bold text-lg">ScholarNet</span>
                </div>
                <p class="text-center text-muted-foreground text-sm">&copy; 2026 ScholarNet. All rights reserved.</p>
                <div class="flex gap-6">
                    <a href="#" class="text-muted-foreground hover:text-primary transition-colors text-sm">Privacy Policy</a>
                    <a href="#" class="text-muted-foreground hover:text-primary transition-colors text-sm">Terms of Service</a>
                    <a href="#" class="text-muted-foreground hover:text-primary transition-colors text-sm">Contact Us</a>
                </div>
            </div>
        </div>
    </footer>
    `;
}

function handleAuthUI() {
    const token = localStorage.getItem("token") || sessionStorage.getItem("token");
    const user = JSON.parse(localStorage.getItem("user") || sessionStorage.getItem("user") || "{}");

    const loginLink = document.getElementById("loginLink");
    const registerLink = document.getElementById("registerLink");
    const dashboardLink = document.getElementById("dashboardLink");
    const logoutBtn = document.getElementById("logoutBtn");

    // Re-bind logout buttons because they might have been re-injected
    const allLogoutBtns = document.querySelectorAll('#logoutBtn');
    allLogoutBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            localStorage.clear();
            sessionStorage.clear();
            window.location.href = "/index.html";
        });
    });

    if (token && user.fullName) {
        if (loginLink) loginLink.style.display = "none";
        if (registerLink) registerLink.style.display = "none";
        if (dashboardLink) {
            dashboardLink.style.display = "inline-flex";
            // Set correct dashboard link based on role
            if (user.role === 'Admin') dashboardLink.href = "/admin/dashboard-admin.html";
            else if (user.role === 'Reviewer') dashboardLink.href = "/reviewer/dashboard-reviewer.html";
            else if (user.role === 'Committee') dashboardLink.href = "/committee/dashboard-committee.html";
            else dashboardLink.href = "/student/dashboard-student.html";
        }
        if (logoutBtn) logoutBtn.style.display = "inline-flex";
    } else {
        if (loginLink) loginLink.style.display = "inline-flex";
        if (registerLink) registerLink.style.display = "inline-flex";
        if (dashboardLink) dashboardLink.style.display = "none";
        if (logoutBtn) logoutBtn.style.display = "none";
    }
}

