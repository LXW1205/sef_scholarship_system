-- Drop tables in reverse dependency order to avoid FK violations
DROP TABLE IF EXISTS ClarificationStatusLookup CASCADE;
DROP TABLE IF EXISTS InterviewStatusLookup CASCADE;
DROP TABLE IF EXISTS EvaluationStatusLookup CASCADE;
DROP TABLE IF EXISTS ApplicationStatusLookup CASCADE;
DROP TABLE IF EXISTS UserRoleLookup CASCADE;
DROP TABLE IF EXISTS Notification CASCADE;
DROP TABLE IF EXISTS Report CASCADE;
DROP TABLE IF EXISTS ClarificationRequest CASCADE;
DROP TABLE IF EXISTS Interview CASCADE;
DROP TABLE IF EXISTS Evaluation CASCADE;
DROP TABLE IF EXISTS Document CASCADE;
DROP TABLE IF EXISTS Application CASCADE;
DROP TABLE IF EXISTS Inquiry CASCADE;
DROP TABLE IF EXISTS Criteria CASCADE;
DROP TABLE IF EXISTS Scholarship CASCADE;
DROP TABLE IF EXISTS Admin CASCADE;
DROP TABLE IF EXISTS CommitteeMember CASCADE;
DROP TABLE IF EXISTS Reviewer CASCADE;
DROP TABLE IF EXISTS Student CASCADE;
DROP TABLE IF EXISTS "User" CASCADE;

-- Create Tables

CREATE TABLE "User" (
    userID SERIAL PRIMARY KEY,
    fullName VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role VARCHAR(20) NOT NULL,
    isActive BOOLEAN DEFAULT TRUE,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Student (
    studentID VARCHAR(20) PRIMARY KEY,
    cgpa DECIMAL(3,2),
    major VARCHAR(100),
    qualification VARCHAR(20),
    yearOfStudy VARCHAR(20),
    expectedGraduation VARCHAR(20),
    familyIncome DECIMAL(12,2),
    UNIQUE (email)
) INHERITS ("User");

CREATE TABLE Reviewer (
    reviewerID VARCHAR(20) PRIMARY KEY,
    department VARCHAR(100),
    UNIQUE (email)
) INHERITS ("User");

CREATE TABLE CommitteeMember (
    committeeID VARCHAR(20) PRIMARY KEY,
    position VARCHAR(50),
    UNIQUE (email)
) INHERITS ("User");

CREATE TABLE Admin (
    adminID VARCHAR(20) PRIMARY KEY,
    adminLevel VARCHAR(20),
    UNIQUE (email)
) INHERITS ("User");

CREATE TABLE Scholarship (
    scholarshipID SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(200), -- Increased length slightly for better descriptions
    amount VARCHAR(50), -- Changed to 50 to accommodate "RM 10,000" etc comfortably
    forQualification VARCHAR(20),
    deadline DATE,
    isActive BOOLEAN DEFAULT TRUE
);

CREATE TABLE Application (
    appID SERIAL PRIMARY KEY,
    studentID VARCHAR(20) NOT NULL,
    scholarshipID INTEGER NOT NULL,
    submissionDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Pending',
    personalStatement TEXT,
    otherScholarships TEXT,
    CONSTRAINT FK_Application_Student FOREIGN KEY (studentID) REFERENCES Student(studentID) ON DELETE CASCADE,
    CONSTRAINT FK_Application_Scholarship FOREIGN KEY (scholarshipID) REFERENCES Scholarship(scholarshipID) ON DELETE CASCADE
);

-- Dependent Tables (Updated keys where necessary)

CREATE TABLE Criteria (
    criteriaID SERIAL PRIMARY KEY,
    scholarshipID INTEGER NOT NULL,
    name VARCHAR(100) NOT NULL,
    weightage INTEGER,
    maxScore DECIMAL(5,2),
    CONSTRAINT FK_Criteria_Scholarship FOREIGN KEY (scholarshipID) REFERENCES Scholarship(scholarshipID) ON DELETE CASCADE
);

CREATE TABLE Inquiry (
    inquiryID SERIAL PRIMARY KEY,
    studentID VARCHAR(20) NOT NULL, -- Matched Student.studentID type
    message TEXT,
    submittedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT FK_Inquiry_Student FOREIGN KEY (studentID) REFERENCES Student(studentID) ON DELETE CASCADE
);

CREATE TABLE Document (
    docID SERIAL PRIMARY KEY,
    appID INTEGER NOT NULL,
    fileName VARCHAR(255) NOT NULL,
    fileType VARCHAR(50),
    uploadDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT FK_Document_Application FOREIGN KEY (appID) REFERENCES Application(appID) ON DELETE CASCADE
);

CREATE TABLE Evaluation (
    evalID SERIAL PRIMARY KEY,
    appID INTEGER NOT NULL,
    reviewerID VARCHAR(20) NOT NULL, -- Renamed from reviewerStaffID and matched type
    scholarshipComments TEXT,
    interviewScore DECIMAL(5,2),
    interviewComments TEXT,
    status VARCHAR(20) DEFAULT 'Pending',
    evaluatedDate TIMESTAMP,
    CONSTRAINT FK_Evaluation_Application FOREIGN KEY (appID) REFERENCES Application(appID) ON DELETE CASCADE,
    CONSTRAINT FK_Evaluation_Reviewer FOREIGN KEY (reviewerID) REFERENCES Reviewer(reviewerID) ON DELETE CASCADE
);

CREATE TABLE Interview (
    interviewID SERIAL PRIMARY KEY,
    evalID INTEGER NOT NULL,
    dateTime TIMESTAMP,
    venueOrLink VARCHAR(255),
    status VARCHAR(20) DEFAULT 'Scheduled',
    CONSTRAINT FK_Interview_Evaluation FOREIGN KEY (evalID) REFERENCES Evaluation(evalID) ON DELETE CASCADE
);

CREATE TABLE ClarificationRequest (
    reqID SERIAL PRIMARY KEY,
    evalID INTEGER NOT NULL,
    question TEXT NOT NULL,
    answer TEXT,
    status VARCHAR(20) DEFAULT 'Pending',
    requestedDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    answeredDate TIMESTAMP,
    CONSTRAINT FK_ClarificationRequest_Evaluation FOREIGN KEY (evalID) REFERENCES Evaluation(evalID) ON DELETE CASCADE
);

CREATE TABLE Report (
    reportID SERIAL PRIMARY KEY,
    adminID VARCHAR(20) NOT NULL, -- Matched Admin.adminID type
    type VARCHAR(50) NOT NULL,
    generatedFile VARCHAR(255),
    generatedDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT FK_Report_Admin FOREIGN KEY (adminID) REFERENCES Admin(adminID) ON DELETE CASCADE
);

CREATE TABLE Notification (
    notifID SERIAL PRIMARY KEY,
    userID INTEGER NOT NULL, -- Note: FK constraint removed due to PostgreSQL inheritance limitations
    message TEXT NOT NULL,
    sentAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    isRead BOOLEAN DEFAULT FALSE
);

-- Lookups (Optional, kept/added for completeness if needed later)
CREATE TABLE UserRoleLookup ( roleValue VARCHAR(20) PRIMARY KEY );
CREATE TABLE ApplicationStatusLookup ( statusValue VARCHAR(20) PRIMARY KEY );
CREATE TABLE EvaluationStatusLookup ( statusValue VARCHAR(20) PRIMARY KEY );
CREATE TABLE InterviewStatusLookup ( statusValue VARCHAR(20) PRIMARY KEY );
CREATE TABLE ClarificationStatusLookup ( statusValue VARCHAR(20) PRIMARY KEY );

-- Audit Log Table for tracking all system changes
CREATE TABLE AuditLog (
    logID SERIAL PRIMARY KEY,
    userID INTEGER,
    userEmail VARCHAR(100),
    action VARCHAR(100) NOT NULL,
    entityType VARCHAR(50),
    entityID VARCHAR(50),
    details TEXT,
    ipAddress VARCHAR(45),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);